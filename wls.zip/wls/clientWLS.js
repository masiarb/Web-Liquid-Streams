 var wid = 2
 ;
 var host = "http://agora.mobile.usilu.net:3031";


 function showOperatorForm() {

    console.log("showOperatorForm");
    $("#left").hide();
    $("#operator_form").show();
    new Dragdealer('demo-simple-slider', {
      animationCallback: function(x) {
        $('#demo-simple-slider .value').text(Math.round(x*10));
        $('#value-hidden').val(Math.round(x*10));
      }
    });

   
 }


  function updateResultsText (operators, tid) {
       $("#left").html("");
       $("#title_top").html("<div id='header'><div id='title'><h2>TOPOLOGY "+tid+"</h2></div><div id='add_operator'><a href='#' onclick='showOperatorForm()'  class='button tiny 3'>Add operator</a></div></div>");
       for (var i = 0; i < operators.length; i++) {
          var name = "O"+operators[i].oid;
          var operatorDiv = $("<div class='operator'>"+
                                  "<h5>Operator <b>O"+operators[i].oid+"</b></h5>"+
                                    "<div class='operator_line'><span class='name'>peer</span>: "+operators[i].peer+"</div>"+
                                    "<div class='operator_line'><span class='name'>script</span>: "+operators[i].script+"</div>"+
                               "</div>");
        
        var workerDiv = "<div><span class='name'>workers</span>: "+operators[i].workers.length+" [";
        for (var w = 0; w < operators[i].workers.length; w++) {
          if(w < operators[i].workers.length - 1) {
            workerDiv += "<b>W"+operators[i].workers[w].wid+"</b>, ";
          } else {
            workerDiv += "<b>W"+operators[i].workers[w].wid+"</b>]";
          }
        }
        workerDiv += "</div>";

        workerDiv += "<div class='worker_button' >"+
                        "<a id='add_worker_operator_"+operators[i].oid+"' onclick='addWorker("+operators[i].oid+", \""+operators[i].script+"\")' class='button tiny 3'>Add worker</a>"+
                      "</div>";
                      


        operatorDiv.append(workerDiv);
        $("#left").append(operatorDiv);

        };
  }


var addWorker = function addWorker(oid, script) {
      wid++;

      var workerData = '{"worker": {"wid": '+wid+', "script": "'+script+'" }}';
      console.log("adding worker = "+wid+" woth script = "+script+" to operator = "+oid);
      $.ajax({
        type: "POST",
        url: host+"/topologies/0/operators/"+oid+"/workers",
        dataType: "text",
        contentType: "text/plain",
        data: workerData,
        success: function(data) {
           var json_data = JSON.parse(data);
            wid = 0;
            var operators = json_data.topologies[0].operators;
            var bindings = json_data.topologies[0].bindings;

            for (var i = 0; i < operators.length; i++) {
              var name = "O"+operators[i].oid;
              graph.addNode(name);

               var workers = operators[i].workers;
               for (var k = 0; k < workers.length; k++) {
                  wid++;
                  var name = "W"+workers[k].wid;
                  graph.addNode(name);
                  graph.addLink("O"+operators[i].oid, "W"+workers[k].wid);
               }
            };

            for(var i = 0; i < bindings.length; i++) {
                graph.addLink("O"+bindings[i].from, "O"+bindings[i].to);
            }

          updateResultsText(json_data.topologies[0].operators, json_data.topologies[0].tid);
        }
      });
  }


function TodoCtrl($scope, $http) {

  angular.module('myApp', ['ngPrettyJson', 'nouislider']);


  console.log("started TODO");
  
  $scope.url = host;
  $scope.methodType = "GET";
  $scope.workers = "1";

  //INITIALIZE BY GETTING FIRST TOPOLOGY
  $http({method: "GET", url: host+"/topologies"}).
    success(function(data, status, headers, config) {
                                                  
        wid = 0;
        var operators = data.topologies[0].operators;
        var bindings = data.topologies[0].bindings;

        for (var i = 0; i < operators.length; i++) {
          var name = "O"+operators[i].oid;
          graph.addNode(name);
          var workers = operators[i].workers;
           for (var k = 0; k < workers.length; k++) {
              wid++;
              var name = "W"+workers[k].wid;
              graph.addNode(name);
              graph.addLink("O"+operators[i].oid, "W"+workers[k].wid);
           }
        };

        for(var i = 0; i < bindings.length; i++) {
           graph.addLink("O"+bindings[i].from, "O"+bindings[i].to);
        }
        updateResultsText(operators, data.topologies[0].tid);

    }).
    error(function(data, status, headers, config) {
        $scope.results = data;
    });


  $scope.todos = [
    {text:'learn angular', done:true},
    {text:'build an angular app', done:false}];
 
  function getResource(url) {
      console.log("GET RESOURCE");
      console.log(url.split("/")[url.split("/").length-1]);
      return url.split("/")[url.split("/").length-1];
  }

  $scope.addOperator = function() {

      console.log("ADD OPERATOR");
      console.log("oid = " + $scope.oid);
      var workers = $("#value-hidden").val();
      console.log("workers = " + $("#value-hidden").val());
      console.log("script = " + $scope.script);
      console.log("peer = " + $scope.peer);
      var data = '{"operator": {"oid": '+$scope.oid+', "script": "'+$scope.script+'", "peer": "'+$scope.peer+'", "browser": false, ';
      data += '"workers": [';
      for(var i = 0; i < workers; i++) {
        data += '{"wid": '+wid+', "href": "/topologies/0/operators/'+$scope.oid+'/workers", "operator": "/topologies/0/operators/'+$scope.oid+'"}';
      }

      data += ']}}';

      

      $.ajax({
        type: "POST",
        url: host+"/topologies/0/operators",
        dataType: "text",
        contentType: "text/plain",
        data: data,
        success: function(data) {
          console.log(data);
          var json_data = JSON.parse(data);
            wid = 0;
            var operators = json_data.topologies[0].operators;
            var bindings = json_data.topologies[0].bindings;

            for (var i = 0; i < operators.length; i++) {
              var name = "O"+operators[i].oid;
              graph.addNode(name);

               var workers = operators[i].workers;
               for (var k = 0; k < workers.length; k++) {
                  wid++;
                  var name = "W"+workers[k].wid;
                  graph.addNode(name);
                  graph.addLink("O"+operators[i].oid, "W"+workers[k].wid);
               }
            };

            for(var i = 0; i < bindings.length; i++) {
                graph.addLink("O"+bindings[i].from, "O"+bindings[i].to);
            }

            updateResultsText(operators, json_data.topologies[0].tid);
            $("#operator_form").hide();
            $("#left").show();
        }
      });

  }
  

  $scope.addTodo = function() {


      $.ajax({
        type: $scope.methodType,
        url: $scope.url,
        dataType: "text",
        contentType: "text/plain",
        data: $scope.data,
        success: function(data) {
           console.log(data);
           var json_data = JSON.parse(data);
            wid = 0;
            var operators = json_data.topologies[0].operators;
            var bindings = json_data.topologies[0].bindings;

            for (var i = 0; i < operators.length; i++) {
              var name = "O"+operators[i].oid;
              graph.addNode(name);

               var workers = operators[i].workers;
               for (var k = 0; k < workers.length; k++) {
                  wid++;
                  var name = "W"+workers[k].wid;
                  graph.addNode(name);
                  graph.addLink("O"+operators[i].oid, "W"+workers[k].wid);
               }
            };

            for(var i = 0; i < bindings.length; i++) {
                graph.addLink("O"+bindings[i].from, "O"+bindings[i].to);
            }

            updateResultsText(operators, json_data.topologies[0].tid);

      },error: function(data) {

          console.log(data);
      }
    });

    $scope.todoText = '';
  };


 




  


  $scope.remaining = function() {
    var count = 0;
    angular.forEach($scope.todos, function(todo) {
      count += todo.done ? 0 : 1;
    });
    return count;
  };
 
  $scope.archive = function() {
    var oldTodos = $scope.todos;
    $scope.todos = [];
    angular.forEach(oldTodos, function(todo) {
      if (!todo.done) $scope.todos.push(todo);
    });
  };
}